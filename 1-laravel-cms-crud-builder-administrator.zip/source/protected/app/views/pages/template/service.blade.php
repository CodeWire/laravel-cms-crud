<div class="wrapper-header ">
<div class="container">
<div class="col-sm-6 col-xs-6">
<div class="page-title">
<h3>Service Page <small> This is sample page </small></h3>
</div>
</div>
<div class="col-sm-6 col-xs-6 ">
<ul class="breadcrumb pull-right">
<li><a href="{{ URL::to('') }}">Home</a></li>
<li class="active">Service Page</li>
</ul>
</div>
</div>
</div>
<div id="w " class="home-intro">
<div class="container">
<div class="row">
<div class="col-lg-8 col-lg-offset-2">
<h3 class="text-center">What We Can Deliver For You</h3>
<p class="text-center">Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. <br> Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
<!-- /container --></div>
<div class="wrapper-container container">
<div class="row text-center service-page">
<div class="col-md-4">
<div class="boxed">
<div class="service-content">
<h3>Power of Flexibility</h3>
<p>Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="boxed">
<div class="service-content">
<h3>Power of Flexibility</h3>
<p>Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="boxed">
<div class="service-content">
<h3>Power of Flexibility</h3>
<p>Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="boxed">
<div class="service-content">
<h3>Power of Flexibility</h3>
<p>Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="boxed">
<div class="service-content">
<h3>Power of Flexibility</h3>
<p>Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
<div class="col-md-4">
<div class="boxed">
<div class="service-content">
<h3>Power of Flexibility</h3>
<p>Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac. Lorem ipsum dolor sit amet sed, consectetur. Ut rutrum auctor orci, sed malesuada sapien faucibus ac.</p>
</div>
</div>
</div>
</div>
</div>
<div id="w " class="home-intro">
<div class="container">
<div class="row">
<div class="col-lg-8 col-lg-offset-2">
<h3 class="text-center">OUR PARTNERS</h3>
<p class="text-center">Here's what some of our awesome partners that we worked with</p>
</div>
</div>
</div>
<!-- /container --></div>
<div class="container">
<div class="brands row">
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/facebook-alt.png" alt="" height="45" width="127"></strong></div>
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/skype-alt.png" alt="" height="45" width="115"></strong></div>
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/twitter-alt.png" alt="" height="45" width="127"></strong></div>
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/yahoo-alt.png" alt="" height="45" width="121"></strong></div>
</div>
<div class="brands row  ">
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/yahoo-alt.png" alt="" height="45" width="121"></strong></div>
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/twitter-alt.png" alt="" height="45" width="127"></strong></div>
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/skype-alt.png" alt="" height="45" width="115"></strong></div>
<div class="col-sm-3"><strong class="brand"><img src="../../uploads/images/images/facebook-alt.png" alt="" height="45" width="127"></strong></div>
</div>
</div>