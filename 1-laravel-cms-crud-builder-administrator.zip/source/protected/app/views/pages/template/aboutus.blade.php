<div class="wrapper-header ">
    <div class=" container">
		<div class="col-sm-6 col-xs-6">
		  <div class="page-title">
			<h3> About Us <small> Who We Are ?</small></h3>
		  </div>
		</div>
		<div class="col-sm-6 col-xs-6 ">
		  <ul class="breadcrumb pull-right">
			<li><a href="{{ URL::to('') }}">Home</a></li>
			<li class="active">About Us </li>
		  </ul>		
		</div>
		  
    </div>
</div>	
	




<div class="container">
			<div class="row text-center">
				<h3 class="text-center">ABOUT US</h3>
				<br>
				<br>
				<div class="col-lg-2"></div>
				<div class="col-lg-8">
				<p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce lectus elit, tincidunt nec turpis sed, accumsan iaculis ipsum. Nulla at augue auctor, tristique erat in, ultricies nunc. Mauris eget metus leo. Ut in mi lacinia, mattis nisl non, ultrices risus. Vestibulum aliquet aliquam ipsum ut ullamcorper. Pellentesque fringilla, massa vel rutrum consequat, nulla velit fermentum dolor, sed scelerisque.</p>
				<br>
				<br>
				</div>
				<div class="col-lg-2"></div>
				<div class="col-lg-3 team">
					<img height="90" width="90" src="sximo/themes/mango/img/team01.jpg" class="img-circle">
					<h4>Liz Stewart</h4>
					<h5><i>Product Manager</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<p>
						<a href="index.html#"><i class="icon-facebook"></i></a>
						<a href="index.html#"><i class="icon-twitter"></i></a>
						<a href="index.html#"><i class="icon-envelope"></i></a>

					</p>
				</div>

				<div class="col-lg-3 team">
					<img height="90" width="90" src="sximo/themes/mango/img/team02.jpg" class="img-circle">
					<h4>Brad Casey</h4>
					<h5><i>Front-end Developer</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<p>
						<a href="index.html#"><i class="icon-facebook"></i></a>
						<a href="index.html#"><i class="icon-twitter"></i></a>
						<a href="index.html#"><i class="icon-envelope"></i></a>

					</p>
				</div>

				<div class="col-lg-3 team">
					<img height="90" width="90" src="sximo/themes/mango/img/team03.jpg" class="img-circle">
					<h4>Pamela Chow</h4>
					<h5><i>Web Designer</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<p>
						<a href="index.html#"><i class="icon-facebook"></i></a>
						<a href="index.html#"><i class="icon-twitter"></i></a>
						<a href="index.html#"><i class="icon-envelope"></i></a>

					</p>
				</div>

				<div class="col-lg-3 team">
					<img height="90" width="90" src="sximo/themes/mango/img/team04.jpg" class="img-circle">
					<h4>Tim Gates</h4>
					<h5><i>Back-end Guru</i></h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<p>
						<a href="index.html#"><i class="icon-facebook"></i></a>
						<a href="index.html#"><i class="icon-twitter"></i></a>
						<a href="index.html#"><i class="icon-envelope"></i></a>

					</p>
				</div>
			</div>
		</div>


		

<div class="container" style="margin-bottom:100px;">
	<div class="row">
	
	
	</div>
</div>					