<?php
return array(	
	"base_url"   => "http://lcrud.mangopik.com/user/socmed",
	"providers"  => array (
		"Google"     => array (
			"enabled"    => true,
			"keys"       => array ( "id" => "1038196167526-euluve7af4mhfgde9vr79a8s1or4t8it", "secret" => "Z_Wq238T-bSWC5Azmyk2jSs6" ),
			),
		"Facebook"   => array (
			"enabled"    => true,
			"keys"       => array ( "id" => "725712687473196", "secret" => "97af69633d9f00e4d3d2e9929574d9e9" ),
			),
		"Twitter"    => array (
			"enabled"    => true,
			"keys"       => array ( "key" => "q2NR24fPB2VtayTOMa6NDAG9s", "secret" => "deLBI0nVkllV1aAOrohk0X9nDJY1tognRQO2myJsGis9GnmBCY" )
			)
	),
);