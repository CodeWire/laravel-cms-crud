<?php 
return array( 
"password"			=> "As senhas devem ter pelo menos seis caracteres e combinar a confirmação.",  
 "user"			=> "Não podemos encontrar um usuário com esse endereço de e-mail.",  
 "token"			=> "Esse token de redefinição de senha é inválido.",  
 "sent"			=> "Senha enviada!",  
 );