<?php 
define('CNF_APPNAME','My Company App');
define('CNF_APPDESC','Internal PHP Application');
define('CNF_COMNAME','My Company Name');
define('CNF_EMAIL','info@mail.com');
define('CNF_METAKEY','my site , my company  , Larvel Crud');
define('CNF_METADESC','Write description for your site');
define('CNF_GROUP','3');
define('CNF_ACTIVATION','confirmation');
define('CNF_MULTILANG','1');
define('CNF_LANG','en');
define('CNF_REGIST','true');
define('CNF_FRONT','true');
define('CNF_RECAPTCHA','false');
define('CNF_THEME','mango');
define('CNF_RECAPTCHAPUBLICKEY','6Ldg6_ISAAAAAGn4r9WpJwL7jEameeErktf4Jjos');
define('CNF_RECAPTCHAPRIVATEKEY','6Ldg6_ISAAAAAMsBDL9GqFq4t5kQzCAOuYFsyKhN');
?>